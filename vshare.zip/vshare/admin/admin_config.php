<?php

define('ADMIN_AREA', true);